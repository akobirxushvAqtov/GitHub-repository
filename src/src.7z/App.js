// import logo from './logo.svg';
import './App.css';
import {Routes, Route, Link} from 'react-router-dom';
import Posts from './components/Posts';
import Post from './components/Post';
import Loader from './components/loader';



function App() {


    return (
        <div>
            <div>
                <Link to='/posts'>Postlar</Link>
            </div>
            <Routes>
                <Route path={'/posts'} element={<Posts/>} />
                <Route path={'/posts/:id'} element={<Posts/>} />
            </Routes>
            
        </div>
    )
}
export default App