import React from 'react';
import { useParams } from 'react-router-dom';
import {useState, useEffect} from 'react'

export default function Post() {

    const params = useParams();
    const [postMessage, setPost] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${params.id}`)
            const data = await res.json();

            setPost(data)
            setLoading(false)
        }
        fetchData()
    }, [])

    if (loading) return <h1>Iltimos, kutib turing... <Loader /></h1>


    return (
        <div>
            <h3>{post.id}. {post.title}</h3>
            <p>{post.body}</p>
        </div>
    )
}
