import React from 'react'
import { useState, useEffect } from 'react'
import{ Link } from 'react-router-dom'
import Loader from './loader';

export default function Posts() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            const response = await fetch('https://jsonplaceholder.typicode.com/posts');
            const data = await response.json();
            console.log('effectni ichidagi')
            setPosts(data)
        }
        fetchPosts();
        setLoading(false)
    }, []);

    console.log('efectni tashqarisidagi')

    if (loading) return <h1>Iltimos, kutib turing... <Loader /></h1>

    return (

        <div>
            {posts.map((posts) =>
                <li key={posts.id}>
                    <Link to={`/posts/${posts.id}>`}></Link>
                    {posts.title}
                    {/* <input type='checkbox' checked={posts.completed} /> */}
                </li>)}
        </div>
    )
}
